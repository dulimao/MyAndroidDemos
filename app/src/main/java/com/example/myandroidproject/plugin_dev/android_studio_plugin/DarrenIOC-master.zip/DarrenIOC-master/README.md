# DarrenIOC
The world of mortals beautiful code

Android Studio Darren注解IOC框架插件

具体博客地址：暂时没有

具体视频讲解：暂时没有

个人QQ：240336124

QQ群：546270670

简介：这是本人写的一个插件，主要用于自己的IOC注解框架中，需要配合本人的开发框架使用。有点类似于ButterKnife注解框架，自己也是仿照网上写，大家
     可以下载源码里面有大量的注释。
     
使用：如果你正在使用我的框架，那么只需要下载jar包插件安装即可，如果没有使用本人的框架就没什么价值所以也就没有发布插件，只是自己和同伴用用而已

插件使用演示：
![效果演示](https://github.com/Shenmowen/DarrenIOC/blob/4409818164dc7f8d6c922c0f7188dd2f5817622d/resources/META-INF/插件使用演示.gif)

