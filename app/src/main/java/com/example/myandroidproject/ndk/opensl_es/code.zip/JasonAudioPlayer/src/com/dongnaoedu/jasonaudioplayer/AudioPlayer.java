package com.dongnaoedu.jasonaudioplayer;

public class AudioPlayer {

	public native static void play(String filePath);
	
	static{
		System.loadLibrary("JasonAudioPlayer");
	}
}
