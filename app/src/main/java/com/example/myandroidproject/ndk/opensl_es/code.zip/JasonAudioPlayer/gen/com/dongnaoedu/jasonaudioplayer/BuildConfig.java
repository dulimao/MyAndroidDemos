/** Automatically generated file. DO NOT MODIFY */
package com.dongnaoedu.jasonaudioplayer;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}